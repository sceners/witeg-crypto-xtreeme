// keygen template by bart/xt

#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <math.h>
#include "resource.h"
#include "asmproc.h"
#define __APP__  "CrackMe 7.0 by WiteG//xtreeme"
#define __WWW__  "http://www.witeg.prv.pl"

// kolory tooltipow
#define TIP_TEXT 0x000099FF
#define TIP_BACK 0x00000000

// kolory linkow
#define LINK_NORMAL 0x00000000
#define LINK_MOVE   0x00666666
#define LINK_DOWN   0x00808080

// breakpoint
#define BPX DebugBreak();

POINT		opnt;
HINSTANCE	hInst;
BOOL		sflag = FALSE;
LOGFONT		lpLF;
HFONT		hEdit,hBold,hUnder,hNorm,hOEM,hAbout;
DWORD		lpOldProc;
BYTE		bLink = 0,bButton = 0;

void GenerateCode(HWND hDlg)
{
unsigned char name[34],sn[68],temp[256];
unsigned int lname,lsn;

	lname = GetDlgItemTextA(hDlg, EDIT_NAME, name, 33);
	lsn =  GetDlgItemTextA(hDlg, EDIT_KEY, sn, 65);
	if ((lname > 4) & (lsn == 64))
	{
		if	((Check_RegCode(sn,name,lname,temp))==0)
		{
			MessageBox(hDlg, "Congratulations. Good work !", "Info", MB_OK+MB_ICONINFORMATION);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////
//
// void AddTip(HANDLE hWnd,unsigned int idTipControl,unsigned char *lpszTooltip)
//
// dodaje okno tooltip-a do podanego elementu okna dialogowego
//
// na wejsciu:
// hWnd         - uchwyt okna glownego
// idTipControl - identyfikator elementu
// lpszTooltip  - tekst tooltip-a
//
///////////////////////////////////////////////////////////////////////////////
void AddTip(HANDLE hWnd,unsigned int idTipControl,unsigned char *lpszTooltip)
{
TOOLINFO lpTi;
HANDLE hWindow,hTip;
static unsigned char szToolTipClass[] = "Tooltips_class32";

	hWindow = GetDlgItem(hWnd,idTipControl);

	if (hWindow != 0)
	{
	// utworz nowe okno tooltip-a
	hTip = CreateWindowEx(WS_EX_TOPMOST,szToolTipClass,0,0,CW_USEDEFAULT,CW_USEDEFAULT, \
	CW_USEDEFAULT,CW_USEDEFAULT,0,0,hInst,0);

	lpTi.cbSize  = sizeof(TOOLINFO);
	lpTi.uFlags  = TTF_SUBCLASS + TTF_IDISHWND;
	lpTi.hwnd    = 0;
	lpTi.hinst   = hInst;

	// uchwyt okna, do ktorego doczepiamy tooltipa
	lpTi.uId      = (DWORD)hWindow;
	lpTi.lpszText = lpszTooltip;

	SendMessage(hTip,WM_SETFONT,(DWORD)hBold,1);

	// dodaj tooltipa do elementu
	SendMessage(hTip,TTM_ADDTOOL,0,(LPARAM)&lpTi);

	// czas po jakim pojawi sie tooltip
	SendMessage(hTip,TTM_SETDELAYTIME,TTDT_INITIAL,700);

	// czas po jakim zniknie tooltip
	SendMessage(hTip,TTM_SETDELAYTIME,TTDT_AUTOPOP,5000);

	// kolor tekstu tooltip-a
	SendMessage(hTip,TTM_SETTIPTEXTCOLOR,TIP_TEXT & 0x00FFFFFF,0);

	// kolor tla tooltip-a
	SendMessage(hTip,TTM_SETTIPBKCOLOR,TIP_BACK & 0x00FFFFFF,0);
	}
}	

///////////////////////////////////////////////////////////////////////////////
//
// void GoURL(unsigned char *lpszUrl)
//
// uruchamia przegladarke lub klienta pocztowego
//
// na wejsciu:
// lpszUrl - link www lub adres e-mail w 
//
///////////////////////////////////////////////////////////////////////////////
void GoURL(unsigned char *lpszUrl)
{

/*
unsigned int i,j;
unsigned char lpszTemp[64];

	j = strlen(lpszUrl);

	strcpy(lpszTemp,lpszUrl);

	for (i = 0;i < j ;i++ )
	{
		// jesli w adresie URL wystepuje '@' to jest to mail
		// wtedy dodaj do uruchamianego linka przedrostek
		// 'mailto' aby uruchomil sie klient poczty
		if (lpszUrl[i] == 0x40)
		{
		strcpy(lpszTemp,"mailto:");
		strcat(lpszTemp,lpszUrl);
		ShellExecute(0,0,lpszTemp,0,0,0);
		return;
		}
	}

	// jesli pierwsze 4 litery sa rozne od 'http', dodaj przedrostek
	// 'http://' do adresu
	if ( ( *(unsigned int *)lpszUrl & 0xDFDFDFDF ) != 0x50545448 )
	{
	strcpy(lpszTemp,"http://");
	strcat(lpszTemp,lpszUrl);
	}

	ShellExecute(0,0,lpszTemp,0,0,0);
*/

	ShellExecute(0,0,lpszUrl,0,0,0);
}


///////////////////////////////////////////////////////////////////////////////
//
// void DrawLink(HANDLE hButton,unsigned int bEnable)
//
// rysuje 3 stanowy button (link)
//
// na wejsciu:
// hButton - uchwyt buttona(musi posiadac flagi BS_OWNERDRAW)
// enable  - 0 normalny stan
//           1 gdy user poruszy mysza nad buttonem
//           2 gdy user nacisnie lewy klawisz myszy nad buttonem
//
// procka korzysta z back bufora, zeby wyeliminowac efekt flickera podczas
// rysowania na buforze
//
///////////////////////////////////////////////////////////////////////////////
void DrawLink(HANDLE hButton,unsigned int bEnable)
{
HDC hDC,hBackDC;
HBRUSH hBR;
HBITMAP hBitmap;
RECT lpLinkRect;
static unsigned char lpLinkText[64];


	// obszar okna
	GetClientRect(hButton,&lpLinkRect);

	// pobierz jego DC
	hDC = GetDC(hButton);

	// utworz kompatybilne DC
	hBackDC = CreateCompatibleDC(hDC);

	// utworz kompatybilna bitmape
	hBitmap = CreateCompatibleBitmap(hDC,lpLinkRect.right,lpLinkRect.bottom);

	// wybierz bitmape do aktualnego dc
	SelectObject(hBackDC,hBitmap); 

	// kolor systemowy dla brusha, jesli ktos
	// ma inny schemat kolorow, wtedy zeby ladnie
	// wygladalo :)
	hBR = GetSysColorBrush(COLOR_BTNFACE);

	// wybierz obiekt dla dx
	SelectObject(hBackDC,hBR);

	// wyczysc obszar buttona
	FillRect(hBackDC,&lpLinkRect,hBR);

	// skasuj brusha
	DeleteObject(hBR);

	// typ fonta i kolor w zaleznosci od stanu
	switch (bEnable)
	{
		case 0:
		SelectObject(hBackDC,hUnder);
		SetTextColor(hBackDC,LINK_NORMAL & 0x00FFFFFF);
		break;

		case 1:
		SelectObject(hBackDC,hUnder);
		SetTextColor(hBackDC,LINK_MOVE & 0x00FFFFFF);
		break;

		case 2:
		SelectObject(hBackDC,hUnder);
		SetTextColor(hBackDC,LINK_DOWN & 0x00FFFFFF);
	}

	// pobierz text z buttona(jest OWNERDRAW wiec trzeba recznie ustawic)
	// bug bug, funkcja czyta poprawnie text do bufora, ale w eax nie zwraca
	// poprawnej liczby znakow(zwraca 1, win95 osr2)
	GetWindowText(hButton,lpLinkText,64);

	// tryb tla
	SetBkMode(hBackDC,TRANSPARENT);

	// rysuj na nowo tekst okna
	DrawText(hBackDC,lpLinkText,strlen(lpLinkText),&lpLinkRect,DT_SINGLELINE | DT_VCENTER | DT_CENTER);

	// pobierz rect ale wg wspolrzednych ekranowych
	GetWindowRect(hButton,&lpLinkRect);

	// kopiuj z back bufora na glowny dc
	BitBlt(hDC,0,0,lpLinkRect.right - lpLinkRect.left,lpLinkRect.bottom - lpLinkRect.top,hBackDC,0,0,SRCCOPY);
	
	// kasuj back dc
	DeleteDC(hBackDC);

	// zwolnij obiek hBitmap
	DeleteObject(hBitmap);

	// zwolnij dc
	ReleaseDC(hButton,hDC);
}


///////////////////////////////////////////////////////////////////////////////
//
// procedura CALLBACK dla elementow LINK
//
///////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK LinkProc(HANDLE hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
LRESULT lRes;
RECT lpRect;
unsigned int x,y;

	lRes = CallWindowProc( (WNDPROC)lpOldProc,hWnd,uMsg,wParam,lParam);

	switch (uMsg)
	{

	case WM_PAINT:
		// button nie jest nacisniety
		//bLink = 0;
		DrawLink(hWnd,0);
		return 1;

	case WM_MOUSEMOVE:
		GetClientRect(hWnd,&lpRect);

		x = lParam & 0x0000FFFF;
		y = lParam >> 16;

		if ( (x  >= lpRect.left) && (x <= lpRect.right) && (y >= lpRect.top) && (y <= lpRect.bottom) )
		{
			// jesli button juz namalowany ustaw tylko capture
			if (bLink == 1)
			{
			SetCapture(hWnd);
			}
			else
			{
			SetCapture(hWnd);
			DrawLink(hWnd,1);

			// ustaw flage oznaczajaca, ze button juz narysowany
			bLink = 1;
			}
			return 1;

		}
		else
		{
		bLink = 0;
		ReleaseCapture();

		// button nie jest nacisniety
		DrawLink(hWnd,0);
		return 1;
		}

	case WM_LBUTTONDOWN:
		DrawLink(hWnd,2);
		return 1;

	case WM_LBUTTONUP:
		DrawLink(hWnd,1);
		return 1;

	}

	// zwracamy taka wartosc jak oryginalna procedura callback
	return lRes;
}



///////////////////////////////////////////////////////////////////////////////
//
// void DrawButton(HANDLE hButton,unsigned int bEnable)
//
// rysuje 3 stanowy button (link)
//
// na wejsciu:
// hButton - uchwyt buttona(musi posiadac flagi BS_OWNERDRAW)
// enable  - 0 normalny stan
//           1 gdy user poruszy mysza nad buttonem
//           2 gdy user nacisnie lewy klawisz myszy nad buttonem
//
// procka korzysta z back bufora, zeby wyeliminowac efekt flickera podczas
// rysowania na buforze
//
///////////////////////////////////////////////////////////////////////////////
void DrawButton(HANDLE hButton,unsigned int bEnable)
{
HDC hDC,hBackDC;
HBRUSH hBR;
HBITMAP hBitmap;
RECT lpLinkRect,lpTempRect;
static unsigned char lpLinkText[64];


	// obszar okna
	GetClientRect(hButton,&lpLinkRect);

	// pobierz jego DC
	hDC = GetDC(hButton);

	// utworz kompatybilne DC
	hBackDC = CreateCompatibleDC(hDC);

	// utworz kompatybilna bitmape
	hBitmap = CreateCompatibleBitmap(hDC,lpLinkRect.right,lpLinkRect.bottom);

	// wybierz bitmape do aktualnego dc
	SelectObject(hBackDC,hBitmap); 

	// kolor systemowy dla brusha, jesli ktos
	// ma inny schemat kolorow, wtedy zeby ladnie
	// wygladalo :)
	hBR = GetSysColorBrush(COLOR_BTNFACE);

	// wybierz obiekt dla dx
	SelectObject(hBackDC,hBR);

	// wyczysc obszar buttona
	FillRect(hBackDC,&lpLinkRect,hBR);

	// skasuj brusha
	DeleteObject(hBR);

	// tryb tla
	SetBkMode(hBackDC,TRANSPARENT);

	// typ fonta i kolor w zaleznosci od stanu
	switch (bEnable)
	{
		case 0:
		SelectObject(hBackDC,hNorm);
		SetTextColor(hBackDC,0);
		DrawEdge(hBackDC,&lpLinkRect,BDR_RAISEDINNER,BF_RECT);
		break;

		case 1:
		SelectObject(hBackDC,hNorm);
		SetTextColor(hBackDC,LINK_MOVE & 0x00FFFFFF);
		DrawEdge(hBackDC,&lpLinkRect,EDGE_RAISED,BF_RECT);
		break;

		case 2:
		SelectObject(hBackDC,hNorm);
		SetTextColor(hBackDC,LINK_MOVE & 0x00FFFFFF);
		DrawEdge(hBackDC,&lpLinkRect,BDR_SUNKENOUTER,BF_RECT);

		lpLinkRect.left += 1;
		lpLinkRect.right += 1;
		lpLinkRect.top += 1;
		lpLinkRect.bottom += 1;


	}
	// pobierz text z buttona(jest OWNERDRAW wiec trzeba recznie ustawic)
	// bug bug, funkcja czyta poprawnie text do bufora, ale w eax nie zwraca
	// poprawnej liczby znakow(zwraca 1, win95 osr2)
	GetWindowText(hButton,lpLinkText,64);

	// rysuj na nowo tekst okna
	DrawText(hBackDC,lpLinkText,strlen(lpLinkText),&lpLinkRect,DT_SINGLELINE | DT_VCENTER | DT_CENTER);

	// focus
	if (bEnable == 1 || bEnable == 2)
	{
		SetTextColor(hBackDC,0);

		GetClientRect(hButton,&lpTempRect);

		lpTempRect.left += 3;
		lpTempRect.right -= 3;

		lpTempRect.bottom -=3;
		lpTempRect.top += 3;

		DrawFocusRect(hBackDC,&lpTempRect);
	}

	// pobierz rect ale wg wspolrzednych ekranowych
	GetWindowRect(hButton,&lpLinkRect);

	// kopiuj z back bufora na glowny dc
	BitBlt(hDC,0,0,lpLinkRect.right - lpLinkRect.left,lpLinkRect.bottom - lpLinkRect.top,hBackDC,0,0,SRCCOPY);
	
	// kasuj back dc
	DeleteDC(hBackDC);

	// zwolnij obiek hBitmap
	DeleteObject(hBitmap);

	// zwolnij dc
	ReleaseDC(hButton,hDC);
}


///////////////////////////////////////////////////////////////////////////////
//
// procedura CALLBACK dla elementow LINK
//
///////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK ButtonProc(HANDLE hWnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
LRESULT lRes;
RECT lpRect;
unsigned int x,y;

	lRes = CallWindowProc( (WNDPROC)lpOldProc,hWnd,uMsg,wParam,lParam);

	switch (uMsg)
	{

	case WM_ERASEBKGND:
		bButton = 0;
		break;

	case WM_PAINT:
		// button nie jest nacisniety
		//bButton = 0;
		if (bButton == 0)
		{
		DrawButton(hWnd,0);
		}
		return 1;

	case WM_KEYUP:
		if (wParam != VK_SPACE) break;

	case WM_LBUTTONUP:
	case WM_MOUSEMOVE:

		GetClientRect(hWnd,&lpRect);

		x = lParam & 0x0000FFFF;
		y = lParam >> 16;

		if ( (x  >= lpRect.left) && (x <= lpRect.right) && (y >= lpRect.top) && (y <= lpRect.bottom) )
		{
			// jesli button juz namalowany ustaw tylko capture
			if (bButton == 1)
			{
			SetCapture(hWnd);
			}
			else
			{
			SetCapture(hWnd);
			DrawButton(hWnd,1);

			// ustaw flage oznaczajaca, ze button juz narysowany
			bButton = 1;
			}
			return 1;

		}
		else
		{
		bButton = 0;
		ReleaseCapture();

		// button nie jest nacisniety
		DrawButton(hWnd,0);
		return 1;
		}

	case WM_KEYDOWN:
		if (wParam != VK_SPACE) break;

	case WM_LBUTTONDOWN:
		bButton = 0;
		DrawButton(hWnd,2);

		return 1;

//	case WM_LBUTTONUP:
//
//		//DrawButton(hWnd,1);
//		return 1;

	}

	// zwracamy taka wartosc jak oryginalna procedura callback
	return lRes;
}



///////////////////////////////////////////////////////////////////////////////
//
//
// tworzy nowa klase na podstawie istniejacej, ustawia nowy adres procedury
// obslugi komunikatow
// 
// na wejsciu:
// idCursor       - id kursora dla nowej klasy
// lpszOldClass   - wskaznik do istniejacej nazwy klasy
// lpszNewClass   - wskaznik do nowej klasy
// lpCallback     - adres procedury callback
// lpOriginalProc - adres DWORDa gdzie zapisany zostanie oryginalny adres
//                  procedury obslugi komunikatow oryginalnej klasy
// hInstace       - module base
// 
// na wyjsciu:
// 0 jesli blad
//
///////////////////////////////////////////////////////////////////////////////
unsigned int SuperClass(HINSTANCE hInstance,WNDPROC *lpOriginalProc,WNDPROC lpCallback,\
unsigned char *lpszNewClass,unsigned char *lpszOldClass,unsigned int idCursor)
{
WNDCLASSEX lpWC;

	lpWC.cbSize = sizeof(WNDCLASSEX);

	// pobierz informacje o klasie
	GetClassInfoEx(0,lpszOldClass,&lpWC);

	// adres oryginalnej procki obslugujacej komunikaty
	*lpOriginalProc = lpWC.lpfnWndProc;

	// ustaw adres nowej procedury obslugujacej
	lpWC.lpfnWndProc = lpCallback;
	
	lpWC.hInstance = hInstance;

	// nazwa nowej klasy
	lpWC.lpszClassName = lpszNewClass;

	// kursor
	if (idCursor != 0)
	lpWC.hCursor = LoadCursor(hInstance,MAKEINTRESOURCE(idCursor));

	// zarejestruj nowa klase, ktora jest rozszerzeniem istniejacej
	return (RegisterClassEx(&lpWC));


}

BOOL CALLBACK DlgP (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
RECT lpTempRect;

	switch (message)
	{
		case WM_INITDIALOG :
			// pobierz font okna dialogowego
			//GetObject((HANDLE)SendMessage(hDlg,WM_GETFONT,0,0),sizeof(LOGFONT),&lpLF);

			lpLF.lfHeight = -12; 
			lpLF.lfWidth = 0;
			lpLF.lfEscapement = 0; 
			lpLF.lfOrientation = 0; 
			lpLF.lfWeight = FW_BOLD; 
			lpLF.lfItalic = 0; 
			lpLF.lfUnderline = 0; 
			lpLF.lfStrikeOut = 0; 
			lpLF.lfCharSet = 0; 
			lpLF.lfOutPrecision = 0; 
			lpLF.lfClipPrecision = 0; 
			lpLF.lfQuality = 0; 
			lpLF.lfPitchAndFamily = 0;
			strcpy(lpLF.lfFaceName,"Arial");

			// font dla editow
			hEdit = CreateFontIndirect(&lpLF);

			lpLF.lfHeight = -11; 
			hBold = CreateFontIndirect(&lpLF);

			lpLF.lfHeight = -12; 
			lpLF.lfWeight = FW_NORMAL;
			hNorm = CreateFontIndirect(&lpLF);

			lpLF.lfHeight = -11; 
			hAbout = CreateFontIndirect(&lpLF);

			lpLF.lfWeight = FW_BOLD;
			lpLF.lfUnderline = 1;
			hUnder = CreateFontIndirect(&lpLF);


			hOEM = GetStockObject(OEM_FIXED_FONT);

			// ustaw fonty pogrubione dla editow
			SendDlgItemMessage(hDlg,EDIT_NAME,WM_SETFONT,(DWORD)hEdit,1);
			SendDlgItemMessage(hDlg,EDIT_KEY,WM_SETFONT,(DWORD)hEdit,1);

			SendDlgItemMessage(hDlg,IDC_NAME,WM_SETFONT,(DWORD)hNorm,1);
			SendDlgItemMessage(hDlg,IDC_KEY,WM_SETFONT,(DWORD)hNorm,1);

			// ustaw margines editow
			SendDlgItemMessage(hDlg,EDIT_NAME,EM_SETMARGINS,EC_LEFTMARGIN,MAKELONG(1,1));
			SendDlgItemMessage(hDlg,EDIT_KEY,EM_SETMARGINS,EC_LEFTMARGIN,MAKELONG(1,1));

			// dodaj tooltipy do elementow okien
			AddTip(hDlg,EDIT_NAME,"Enter your name here.");
			AddTip(hDlg,EDIT_KEY,"Enter your serial number.");
			AddTip(hDlg,BT_GENERATE,"Check your n/sn combination.");
			AddTip(hDlg,IDC_WWW,"Visit my website.");

			// ustaw text linka
			SetWindowText(hDlg, __APP__);

			// title bar
			SetDlgItemText(hDlg,IDC_WWW,__WWW__);

			SendDlgItemMessage(hDlg,EDIT_NAME,EM_SETLIMITTEXT,32,0);
			SendDlgItemMessage(hDlg,EDIT_KEY,EM_SETLIMITTEXT,64,0);
			
			return TRUE;
		case WM_COMMAND :
			switch (LOWORD (wParam))
			{
				case IDC_WWW:
					GoURL(__WWW__);
					break;
				case BT_GENERATE :
					GenerateCode(hDlg);
					//SetFocus(GetDlgItem(hDlg, EDIT_KEY));
					break;
				case IDCANCEL :
					EndDialog (hDlg, 0);
					break;
			}
			break;
	}
	return FALSE;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	// module base
	hInst = hInstance;

	// inicjalizacja comm ctrl (m.in. dla tooltipow)
	InitCommonControls();

	// utworz nowa klase dla linkow
	SuperClass(hInst,&lpOldProc,&LinkProc,"LINK","BUTTON",IDC_CUR_HAND);

	// utworz nowa klase dla moich buttonow
	SuperClass(hInst,&lpOldProc,&ButtonProc,"BUTT","BUTTON",0);


	// utworz glowne okno aplikacji
	DialogBoxA(hInstance, MAKEINTRESOURCE(DLG_MAIN), 0, DlgP);
	return 0;
}
