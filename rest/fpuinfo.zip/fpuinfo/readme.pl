[Przeznaczenie]
FPU Info zgodnie z nazwa dostarcza informacji o koprocesorze, a wlasciwie o jego stanie. Bylo mi cos takiego potrzebne do debugowania progow korzystajacych z FPU (glownie VBasicowych). Pierwotnie mialo byc to tylko dla rejestru kontrolnego ale mi sie jakos dobrze kodowalo ;)

[Obsluga]
Do jego obslugi potrzebny jest SoftIce. Po zaladowaniu vxd'ka (np. VXD Loaderem ZetX'a/CookieCrK)
wpisujesz w procesie wykorzystujacym koprocesor po jego zainicjowaniu:
.fpuinfo parametr

parametr	opis
CTRL		przedstawia zawartosc rejestru kontrolnego
STAT		przedstawia zawartosc rejestru stanu
TAG		przedstawia zawartosc rejestru stosu koprocesora
REST		przedstawia zawartosc rejestrow wskaznika argumentu i wskaznika instrukcji
ALL		wywala wszystko na raz ;)

[Zasady]
Freeware. Koniec zasad.

[Autor]
Copyright 2000 WiteG

[Pytania, wnioski, komentarze]
Slijcie wszystko na WiteG@poczta.fm